--nome dos condutores ordenados alfabeticamente
.mode columns
.headers on
.nullvalue NULL

select Nome from Condutor order by Nome;