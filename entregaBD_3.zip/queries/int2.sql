--matricula dos autocarros
.mode columns
.headers on
.nullvalue NULL

select Matricula from Autocarro;
