SELECT EmFuncionamento FROM Paragem WHERE idParagem=995;

INSERT INTO DesativaçãoParagem values(4, 995);

SELECT EmFuncionamento FROM Paragem WHERE idParagem=995;
