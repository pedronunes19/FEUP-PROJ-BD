SELECT EmFuncionamento FROM Linha WHERE idLinha=1;

INSERT INTO DesativaçãoLinha values(5, 1);

SELECT EmFuncionamento FROM Linha WHERE idLinha=1;