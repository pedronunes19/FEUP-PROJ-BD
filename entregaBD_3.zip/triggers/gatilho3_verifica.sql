SELECT Hora FROM Passagem WHERE idPassagem=130;

INSERT INTO AlteraçãoHorário values(6, 130);	

SELECT Hora FROM Passagem WHERE idPassagem=130;
